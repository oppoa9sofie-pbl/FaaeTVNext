# FaaeTV Next — Android project

Aplikasi Android berbasis WebView dengan dashboard olahraga, kategori, pencarian platform, favorit lokal, dan tautan ke penyedia streaming resmi.

## Build APK melalui HP (GitHub Actions)
1. Buat akun di https://github.com/signup dan verifikasi email.
2. Buat repository baru bernama `FaaeTVNext` dan pilih **Public** atau **Private**.
3. Ekstrak ZIP proyek ini di HP. Unggah seluruh isi folder `FaaeTVNext-Android` ke root repository (jangan mengunggah folder pembungkusnya).
4. Buka tab **Actions**, pilih workflow **Build FaaeTV Next APK**, lalu tekan **Run workflow**.
5. Setelah proses selesai dengan status hijau, buka hasil run dan unduh artifact `FaaeTVNext-debug-apk`.
6. Ekstrak artifact dan pasang `app-debug.apk` di Android.

Workflow GitHub Actions sudah disiapkan untuk mengompilasi APK di server GitHub menggunakan Java 17, Gradle 8.7, dan Android SDK 35.

## Catatan fitur
- Tombol platform membuka situs penyedia melalui WebView.
- Akses konten, login, langganan, hak siar, dan DRM dikendalikan penyedia.
- Jadwal pertandingan live dan skor real-time belum terhubung ke API data olahraga.
- Aplikasi tidak meng-host atau menyediakan stream bajakan.
